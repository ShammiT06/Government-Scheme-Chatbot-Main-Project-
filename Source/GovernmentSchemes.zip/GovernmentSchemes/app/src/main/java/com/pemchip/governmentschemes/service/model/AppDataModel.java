package com.pemchip.governmentschemes.service.model;

import android.content.Context;

import com.pemchip.governmentschemes.common.CustomLog;

import java.io.IOException;
import java.io.InputStream;

public class AppDataModel {

    public static String __DEPARTMENT_LIST = "data/departments_list/departments.json";

    public static String createPath(String dataPath){
        if (dataPath.equalsIgnoreCase("LIST")){
            return __DEPARTMENT_LIST;
        }else{
            return "data/department_data/department_"+dataPath+".json";
        }
    }

    public static String loadJSONFromAsset(Context mContext,String mPath) {
        if(mContext==null)return "";

        CustomLog.trace("PATH: "+createPath(mPath));

        String json = null;
        try {
            InputStream mInputStream = mContext.getAssets().open(createPath(mPath));
            int size = mInputStream.available();
            byte[] buffer = new byte[size];
            mInputStream.read(buffer);
            mInputStream.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
