package com.pemchip.governmentschemes.common;

public class PreferenceKey {

    //FCM
    public static final String FCM_TOKEN = "fcm_token";
    public static final String ADMIN_FCM_TOKEN = "admin_fcm_token";

    //ROLE
    public static final String ROLE = "role";
    public static final String ADMIN_ROLE = "admin";
    public static final String CUSTOMER_ROLE = "user";
    public static final String USER_ID = "user_id";
    public static final String USER_NAME = "user_name";
    public static final String USER_TYPE = "user_type";
    public static final String USER_CHECK_IN = "user_check_in";
    public static final String APP_LANGUAGE = "app_language";
}

