package com.pemchip.governmentschemes.model;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.pemchip.governmentschemes.R;
import com.pemchip.governmentschemes.common.CommonUtils;
import com.pemchip.governmentschemes.common.PreferenceKey;

public class LanguageChooseActivity extends BaseActivity {

    private View hld_back;
    private Button okay_button;
    private RadioGroup radio_group;
    private RadioButton btn_english, btn_tamil;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        hld_back = findViewById(R.id.hld_back);
        okay_button = findViewById(R.id.okay_button);
        radio_group = findViewById(R.id.radio_group);
        btn_english = findViewById(R.id.btn_english);
        btn_tamil = findViewById(R.id.btn_tamil);

        String mCurrentAppLanguage = mPreferencesSession.getStringData(PreferenceKey.APP_LANGUAGE);
        if(CommonUtils.isEmptyStr(mCurrentAppLanguage)){
            mCurrentAppLanguage = "en";
        }

        if(mCurrentAppLanguage.equalsIgnoreCase("en")){
            btn_english.setChecked(true);
        }

        if(mCurrentAppLanguage.equalsIgnoreCase("tl")){
            btn_tamil.setChecked(true);
        }

        setUpListeners();
    }

    private void setUpListeners() {

        hld_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LanguageChooseActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

        okay_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LanguageChooseActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

        radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (checkedId==R.id.btn_english){
                    mPreferencesSession.saveStringData(PreferenceKey.APP_LANGUAGE,"en");
                    setAppLocale();

                }

                if (checkedId==R.id.btn_tamil){
                    mPreferencesSession.saveStringData(PreferenceKey.APP_LANGUAGE,"tl");
                    setAppLocale();

                }
            }
        });

    }
}
