package com.pemchip.governmentschemes.service;

import org.json.JSONObject;

public class ResponseModel {

    private JSONObject mObject;

    public ResponseModel(JSONObject mObj) {
        mObject = mObj;
    }

    public String getDepartmentName_EN() {
        return mObject.optString("department_name_en");
    }

    public String getDepartmentName_TL() {
        return mObject.optString("department_name_tl");
    }

    public String getDepartmentID() {
        return mObject.optString("department_id");
    }

    public String getType() {
        return mObject.optString("type");
    }

    public String getImage() {
        return mObject.optString("image");
    }

    public String getHeading_EN() {
        return mObject.optString("heading_en");
    }

    public String getHeading_TL() {
        return mObject.optString("heading_tl");
    }

    public String getSmallHeading_EN() {
        return mObject.optString("small_heading_en");
    }

    public String getSmallHeading_TL() {
        return mObject.optString("small_heading_tl");
    }


    public String getDescription_EN() {
        return mObject.optString("description_en");
    }

    public String getDescription_TL() {
        return mObject.optString("description_tl");
    }

    public String getLink_1() {
        return mObject.optString("link_1");
    }

    public String getLink_2() {
        return mObject.optString("link_2");
    }
}
