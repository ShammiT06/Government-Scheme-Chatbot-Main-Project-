package com.pemchip.governmentschemes.common;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesSession extends PreferenceKey {

    Context mContext;
    SharedPreferences mPreferences;
    SharedPreferences.Editor mEditor;
    private static PreferencesSession mPreferencesSession = null;
    private static final String PREFERENCE_KEY = "PREF&E$RE@N@CEKEYSSPOS";

    public static PreferencesSession getInstance(Context context) {
        if (mPreferencesSession == null) {
            mPreferencesSession = new PreferencesSession(context);
        }
        return mPreferencesSession;
    }

    @SuppressLint("CommitPrefEdits")
    public PreferencesSession(Context context) {
        super();
        this.mContext = context;
        mPreferences = this.mContext.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();
    }

    public void saveStringData(String key, String value) {
        mEditor.putString(key, value);
        mEditor.commit();
    }

    public void saveBooleanData(String key, boolean value) {
        mEditor.putBoolean(key, value);
        mEditor.commit();
    }

    public String getStringData(String urlKey) {
        return mPreferences.getString(urlKey, "");
    }

    public boolean getBooleanData(String urlKey) {
        return mPreferences.getBoolean(urlKey, false);
    }

    public boolean isLoggedIn() {
        if (!getUserRole().isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public String getUserRole() {
        return mPreferences.getString(ROLE, "");
    }

    public String getAppLanguage() {
        return mPreferences.getString(APP_LANGUAGE, "en");
    }

    public boolean isAppLanguageTamil(){
        return getAppLanguage().equals("tl");

    }
    public void logout() {
        saveStringData(PreferenceKey.ROLE, "");
        saveStringData(PreferenceKey.USER_ID,"");
        saveStringData(PreferenceKey.USER_NAME,"");
        saveBooleanData(PreferenceKey.USER_CHECK_IN,false);
        saveStringData(PreferenceKey.APP_LANGUAGE,"en");
    }
}
