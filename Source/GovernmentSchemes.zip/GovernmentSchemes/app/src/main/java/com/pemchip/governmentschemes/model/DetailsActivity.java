package com.pemchip.governmentschemes.model;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.pemchip.governmentschemes.R;
import com.pemchip.governmentschemes.common.CommonUtils;
import com.pemchip.governmentschemes.service.ResponseModel;
import com.pemchip.governmentschemes.service.model.AppDataModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class DetailsActivity extends BaseActivity {

    private Context mContext;
    private View hld_back,data_view,hld_loader;
    private LinearLayout content_view;
    private TextView action_bar_name;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mContext = null;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_detail);

        hld_back = findViewById(R.id.hld_back);
        action_bar_name = findViewById(R.id.action_bar_name);
        data_view = findViewById(R.id.data_view);
        content_view = findViewById(R.id.content_view);
        hld_loader = findViewById(R.id.hld_loader);

        if(getIntent()!=null){
            action_bar_name.setText(getIntent().getStringExtra("DEPARTMENT_NAME"));
        }

        setUpListeners();
        getDepartmentDetails();
    }

    private void setUpListeners() {

        hld_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void getDepartmentDetails() {
        if (mContext == null) return;

        String mDepartmentID = getIntent().getStringExtra("DEPARTMENT_ID");

        String departmentDetails = AppDataModel.loadJSONFromAsset(mContext,mDepartmentID);
        if(CommonUtils.isEmptyStr(departmentDetails)){
            hld_loader.setVisibility(View.VISIBLE);
            data_view.setVisibility(View.GONE);
            return;
        }

        JSONArray mJSONArray = null;
        try {
            mJSONArray = new JSONArray(departmentDetails);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        hld_loader.setVisibility(View.GONE);
        data_view.setVisibility(View.VISIBLE);

        for (int i = 0; i < mJSONArray.length(); i++) {
            JSONObject jsonValue = mJSONArray.optJSONObject(i);
            ResponseModel mResponseModel = new ResponseModel(jsonValue);

            if(mResponseModel!=null){
                if(mResponseModel.getType().equalsIgnoreCase("image")){
                    View mImageView = getImageView(mResponseModel);
                    if(mImageView!=null){
                        content_view.addView(mImageView);
                    }
                }
                if(mResponseModel.getType().equalsIgnoreCase("heading")){
                    View mHeadingView = getHeadingView(mResponseModel);
                    if(mHeadingView!=null){
                        content_view.addView(mHeadingView);
                    }
                }
                if(mResponseModel.getType().equalsIgnoreCase("small_heading")){
                    View mSmallHeadingView = getSmallHeadingView(mResponseModel);
                    if(mSmallHeadingView!=null){
                        content_view.addView(mSmallHeadingView);
                    }
                }
                if(mResponseModel.getType().equalsIgnoreCase("description")){
                    View mDescriptionView = getDescriptionView(mResponseModel);
                    if(mDescriptionView!=null){
                        content_view.addView(mDescriptionView);
                    }
                }
                if (mResponseModel.getType().equalsIgnoreCase("link")) {
                    View mLinkView = getLinkView(mResponseModel);
                    if (mLinkView != null) {
                        content_view.addView(mLinkView);
                    }
                }
            }
        }

    }

    private View getLinkView(ResponseModel mResponseModel) {
        if(mContext==null)return null;
        LayoutInflater vi = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View mLinkView = vi.inflate(R.layout.custom_link_view, null);
        TextView link_1 = mLinkView.findViewById(R.id.link_1);
        TextView link_2 = mLinkView.findViewById(R.id.link_2);
        link_1.setMovementMethod(LinkMovementMethod.getInstance());
        link_2.setMovementMethod(LinkMovementMethod.getInstance());
        link_1.setText(Html.fromHtml(mResponseModel.getLink_1()));
        link_2.setText(Html.fromHtml(mResponseModel.getLink_2()));
        link_2.setVisibility(View.VISIBLE);
        if (CommonUtils.isEmptyStr(mResponseModel.getLink_2())){
            link_2.setVisibility(View.GONE);
        }

        return mLinkView;
    }

    private View getDescriptionView(ResponseModel mResponseModel) {
        if(mContext==null)return null;
        LayoutInflater vi = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View mDescriptionView = vi.inflate(R.layout.custom_description_view, null);
        TextView description = mDescriptionView.findViewById(R.id.description);
        description.setText(mResponseModel.getDescription_EN());
        if(mPreferencesSession.isAppLanguageTamil()){
            description.setText(mResponseModel.getDescription_TL());
        }
        return mDescriptionView;
    }

    private View getHeadingView(ResponseModel mResponseModel) {
        if(mContext==null)return null;
        LayoutInflater vi = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View mHeadingView = vi.inflate(R.layout.custom_heading_view, null);
        TextView heading = mHeadingView.findViewById(R.id.heading);
        heading.setText(Html.fromHtml(mResponseModel.getHeading_EN()));
        if(mPreferencesSession.isAppLanguageTamil()){
            heading.setText(Html.fromHtml(mResponseModel.getHeading_TL()));
        }
        return mHeadingView;
    }

    private View getSmallHeadingView(ResponseModel mResponseModel) {
        if(mContext==null)return null;
        LayoutInflater vi = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View mSmallHeadingView = vi.inflate(R.layout.custom_small_heading_view, null);
        TextView small_heading = mSmallHeadingView.findViewById(R.id.small_heading);
        small_heading.setText(Html.fromHtml(mResponseModel.getSmallHeading_EN()));
        if(mPreferencesSession.isAppLanguageTamil()){
            small_heading.setText(Html.fromHtml(mResponseModel.getSmallHeading_TL()));
        }
        return mSmallHeadingView;
    }

    private View getImageView(ResponseModel mResponseModel) {
        if(mContext==null)return null;
        LayoutInflater vi = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View mImageView = vi.inflate(R.layout.custom_image_view, null);
        ImageView image = mImageView.findViewById(R.id.image);
        Glide.with(mContext).load(mResponseModel.getImage()).into(image);
        return mImageView;
    }

}
