package com.pemchip.governmentschemes.model;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.pemchip.governmentschemes.R;
import com.pemchip.governmentschemes.common.CommonUtils;

public class HomeActivity extends BaseActivity {

    private Context mContext;
    private View btn_profile;
    private View hld_e_sevai,hld_departments;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mContext = null;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_home);

        btn_profile = findViewById(R.id.btn_profile);
        hld_e_sevai = findViewById(R.id.hld_e_sevai);
        hld_departments = findViewById(R.id.hld_departments);

        setUpListeners();
    }

    private void setUpListeners() {
        if (mContext==null)return;

        btn_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

        hld_e_sevai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, DetailsActivity.class);
                intent.putExtra("DEPARTMENT_ID","0");
                intent.putExtra("DEPARTMENT_NAME",mContext.getResources().getString(R.string.e_Sevai));
                startActivity(intent);
            }
        });

        hld_departments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, DepartmentListActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(CommonUtils.isLanguageChanged){
            CommonUtils.isLanguageChanged = false;
            finish();
            startActivity(getIntent());
        }
    }
}
