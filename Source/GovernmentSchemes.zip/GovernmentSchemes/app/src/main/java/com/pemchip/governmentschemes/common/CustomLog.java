package com.pemchip.governmentschemes.common;

import android.util.Log;

public class CustomLog {

    public static void trace(String msg){
        Log.e("SK_TRACE: ",""+msg);
    }
}
