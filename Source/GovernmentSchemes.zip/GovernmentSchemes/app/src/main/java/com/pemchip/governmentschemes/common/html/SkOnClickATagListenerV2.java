package com.pemchip.governmentschemes.common.html;

import android.view.View;

import androidx.annotation.Nullable;

/**
 * This listener can define what happens when the a tag is clicked
 */
public interface SkOnClickATagListenerV2 {
    /**
     * Notifies of anchor tag click events.
     * @param widget - the {@link SkHtmlTextViewV2} instance
     * @param spannedText - the string value of the text spanned
     * @param href - the url for the anchor tag
     * @return indicates whether the click event has been handled
     */
    boolean onClick(View widget, String spannedText, @Nullable String href);
}
