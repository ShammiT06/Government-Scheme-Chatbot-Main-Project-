package com.pemchip.governmentschemes.common.html;

import android.content.Context;
import android.text.Html;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RawRes;

import java.io.InputStream;
import java.util.Scanner;

public class SkHtmlTextViewV2 extends SkJellyBeanSpanFixTextViewV2 {

    public static final String TAG = "HtmlTextView";
    public static final boolean DEBUG = false;

    @Nullable
    private SkClickableTableSpanV2 skClickableTableSpanV2;
    @Nullable
    private SkDrawTableLinkSpanV2 skDrawTableLinkSpanV2;

    private boolean removeFromHtmlSpace = true;

    public SkHtmlTextViewV2(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public SkHtmlTextViewV2(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SkHtmlTextViewV2(Context context) {
        super(context);
    }


    public void setHtml(@RawRes int resId) {
        setHtml(resId, null);
    }

    public void setHtml(@NonNull String html) {
        setHtml(html, null);
    }

    /**
     * Loads HTML from a raw resource, i.e., a HTML file in res/raw/.
     * This allows translatable resource (e.g., res/raw-de/ for german).
     * The containing HTML is parsed to Android's Spannable format and then displayed.
     *
     * @param resId       for example: R.raw.help
     * @param imageGetter for fetching images. Possible ImageGetter provided by this library:
     *                    HtmlLocalImageGetter and HtmlRemoteImageGetter
     */
    public void setHtml(@RawRes int resId, @Nullable Html.ImageGetter imageGetter) {
        InputStream inputStreamText = getContext().getResources().openRawResource(resId);

        setHtml(convertStreamToString(inputStreamText), imageGetter);
    }

    /**
     * Parses String containing HTML to Android's Spannable format and displays it in this TextView.
     * Using the implementation of Html.ImageGetter provided.
     *
     * @param html        String containing HTML, for example: "<b>Hello world!</b>"
     * @param imageGetter for fetching images. Possible ImageGetter provided by this library:
     *                    HtmlLocalImageGetter and HtmlRemoteImageGetter
     */
    public void setHtml(@NonNull String html, @Nullable Html.ImageGetter imageGetter) {
        final SkHtmlTagHandlerV2 skHtmlTagHandlerV2 = new SkHtmlTagHandlerV2(getPaint());
        skHtmlTagHandlerV2.setSkClickableTableSpanV2(skClickableTableSpanV2);
        skHtmlTagHandlerV2.setSkDrawTableLinkSpanV2(skDrawTableLinkSpanV2);

        html = skHtmlTagHandlerV2.overrideTags(html);

        if (removeFromHtmlSpace) {
            setText(removeHtmlBottomPadding(Html.fromHtml(html, imageGetter, skHtmlTagHandlerV2)));
        } else {
            setText(Html.fromHtml(html, imageGetter, skHtmlTagHandlerV2));
        }

        // make links work
        setMovementMethod(SkLocalLinkMovementMethodV2.getInstance());
    }

    /**
     * Note that this must be called before setting text for it to work
     */
    public void setRemoveFromHtmlSpace(boolean removeFromHtmlSpace) {
        this.removeFromHtmlSpace = removeFromHtmlSpace;
    }

    public void setSkClickableTableSpanV2(@Nullable SkClickableTableSpanV2 skClickableTableSpanV2) {
        this.skClickableTableSpanV2 = skClickableTableSpanV2;
    }

    public void setSkDrawTableLinkSpanV2(@Nullable SkDrawTableLinkSpanV2 skDrawTableLinkSpanV2) {
        this.skDrawTableLinkSpanV2 = skDrawTableLinkSpanV2;
    }

    /**
     * http://stackoverflow.com/questions/309424/read-convert-an-inputstream-to-a-string
     */
    @NonNull
    static private String convertStreamToString(@NonNull InputStream is) {
        Scanner s = new Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    /**
     * Html.fromHtml sometimes adds extra space at the bottom.
     * This methods removes this space again.
     * See https://github.com/SufficientlySecure/html-textview/issues/19
     */
    @Nullable
    static private CharSequence removeHtmlBottomPadding(@Nullable CharSequence text) {
        if (text == null) {
            return null;
        }

        while (text.length() > 0 && text.charAt(text.length() - 1) == '\n') {
            text = text.subSequence(0, text.length() - 1);
        }
        return text;
    }

}