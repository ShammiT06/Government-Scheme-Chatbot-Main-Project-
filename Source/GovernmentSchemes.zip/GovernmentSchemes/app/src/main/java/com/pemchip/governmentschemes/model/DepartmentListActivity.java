package com.pemchip.governmentschemes.model;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.pemchip.governmentschemes.R;
import com.pemchip.governmentschemes.common.CommonUtils;
import com.pemchip.governmentschemes.common.CustomLog;
import com.pemchip.governmentschemes.service.ResponseModel;
import com.pemchip.governmentschemes.service.model.AppDataModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class DepartmentListActivity extends BaseActivity {

    private Context mContext;
    private View hld_back;
    private RecyclerView list_recyclerview;
    private View hld_loader;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private ArrayList<ResponseModel> mResponseArrayList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.department_list_activity);

        hld_back = findViewById(R.id.hld_back);
        hld_loader = findViewById(R.id.hld_loader);
        list_recyclerview = findViewById(R.id.list_recyclerview);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("departments");

        hld_loader.setVisibility(View.VISIBLE);
        list_recyclerview.setVisibility(View.GONE);

        setUpListeners();
        getDepartmentsList();

    }

    private void setUpListeners() {

        hld_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void getDepartmentsList() {
        if (mContext == null) return;

        CustomLog.trace("DEBUG: getDepartmentsList");

        mResponseArrayList.clear();

        String departments = AppDataModel.loadJSONFromAsset(mContext,"LIST");
        if(CommonUtils.isEmptyStr(departments)){
            hld_loader.setVisibility(View.GONE);
            list_recyclerview.setVisibility(View.GONE);
            return;
        }

        JSONArray mJSONArray = null;
        try {
            mJSONArray = new JSONArray(departments);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        for (int i = 0; i < mJSONArray.length(); i++) {
            JSONObject jsonValue = mJSONArray.optJSONObject(i);
            ResponseModel mResponseModel = new ResponseModel(jsonValue);
            mResponseArrayList.add(mResponseModel);
        }

        if (mResponseArrayList.size() > 0) {
            list_recyclerview.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.VERTICAL, false));
            list_recyclerview.setItemAnimator(new DefaultItemAnimator());
            list_recyclerview.setHasFixedSize(true);
            ResponseListAdapter mBooksListAdapter = new ResponseListAdapter(DepartmentListActivity.this, mResponseArrayList);
            list_recyclerview.setAdapter(mBooksListAdapter);
        }

        CustomLog.trace("DEBUG: mResponseArrayList: "+mResponseArrayList.size());

        hld_loader.setVisibility(View.GONE);
        list_recyclerview.setVisibility(View.VISIBLE);
    }

    private class ResponseListAdapter extends RecyclerView.Adapter<ResponseListAdapter.MyViewHolder>{
        private Activity context;
        private ArrayList<ResponseModel> mResponseModelList;

        public class MyViewHolder extends RecyclerView.ViewHolder {
            View hld_content;
            TextView name;

            public MyViewHolder(View view) {
                super(view);
                hld_content = view.findViewById(R.id.hld_content);
                name = view.findViewById(R.id.name);
            }
        }

        public ResponseListAdapter(Activity context, ArrayList<ResponseModel> responseModelList) {
            this.context = context;
            this.mResponseModelList = responseModelList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.department_list_adapter, parent, false);
            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int position) {

            ResponseModel mResponseModel = mResponseModelList.get(position);
            holder.name.setText(mResponseModel.getDepartmentName_EN());
            if(mPreferencesSession.isAppLanguageTamil()){
                holder.name.setText(Html.fromHtml(mResponseModel.getDepartmentName_TL()));
            }
            holder.hld_content.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String mDepartmentID = mResponseModel.getDepartmentID();
                    Intent intent = new Intent(DepartmentListActivity.this, DetailsActivity.class);
                    intent.putExtra("DEPARTMENT_ID",mDepartmentID);
                    intent.putExtra("DEPARTMENT_NAME",holder.name.getText().toString());
                    startActivity(intent);
                }
            });
        }

        @Override
        public long getItemId(int id) {
            return id;
        }

        @Override
        public int getItemCount() {
            return mResponseModelList.size();
        }
    }


}
