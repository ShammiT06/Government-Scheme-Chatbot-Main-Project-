package com.pemchip.governmentschemes.model;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.pemchip.governmentschemes.R;
import com.pemchip.governmentschemes.common.CommonUtils;
import com.pemchip.governmentschemes.common.CustomLog;
import com.pemchip.governmentschemes.common.PreferenceKey;
import com.pemchip.governmentschemes.common.PreferencesSession;

import java.util.concurrent.TimeUnit;

public class LoginActivity extends BaseActivity {

    private Context mContext;
    private TextInputEditText input_phone_number, input_otp;
    private Button btn_login, btn_submit_otp;
    private View hld_phone_number, hld_otp, loader;
    private TextView label;
    private FirebaseAuth mAuth;
    private PreferencesSession mPreferencesSession;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String mVerificationId;
    private PhoneAuthProvider.ForceResendingToken mResendToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mContext = this;

        mAuth = FirebaseAuth.getInstance();
        input_phone_number = findViewById(R.id.input_phone_number);
        input_otp = findViewById(R.id.input_otp);
        btn_login = findViewById(R.id.btn_login);
        btn_submit_otp = findViewById(R.id.btn_submit_otp);
        loader = findViewById(R.id.loader);
        hld_phone_number = findViewById(R.id.hld_phone_number);
        hld_otp = findViewById(R.id.hld_otp);
        label = findViewById(R.id.label);

        mPreferencesSession = new PreferencesSession(this);


        //adding on click listener for our login button.
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = input_phone_number.getText().toString();

                if (CommonUtils.isEmptyStr(number)) {
                    Toast.makeText(LoginActivity.this, "Please enter a number", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    btn_login.setVisibility(View.GONE);
                    loader.setVisibility(View.VISIBLE);
                    triggerPhoneCode(number);
                }
            }
        });

        btn_submit_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String otp = input_otp.getText().toString();

                if (CommonUtils.isEmptyStr(otp)) {
                    Toast.makeText(LoginActivity.this, "Please enter a OTP code", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    btn_submit_otp.setVisibility(View.GONE);
                    loader.setVisibility(View.VISIBLE);
                    verifyPhoneNumberWithCode(otp);
                }
            }
        });

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                CustomLog.trace("DEBUG: onVerificationCompleted");
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
                CustomLog.trace("DEBUG: onVerificationFailed");
                hld_phone_number.setVisibility(View.VISIBLE);
                btn_login.setVisibility(View.VISIBLE);
                loader.setVisibility(View.GONE);
                Toast.makeText(mContext, "SMS verification code request failed", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(verificationId, forceResendingToken);
                CustomLog.trace("DEBUG: Code Sent");
                mVerificationId = verificationId;
                mResendToken = forceResendingToken;

                btn_login.setVisibility(View.GONE);
                hld_phone_number.setVisibility(View.GONE);
                loader.setVisibility(View.GONE);
                btn_submit_otp.setVisibility(View.VISIBLE);
                hld_otp.setVisibility(View.VISIBLE);
                label.setText("Please enter OTP code you received");
                Toast.makeText(mContext, "OTP sent successfully to your phone number", Toast.LENGTH_SHORT).show();

            }
        };
    }

    private void triggerPhoneCode(String phoneNumber) {
        if (mContext == null) return;

        phoneNumber = "+91 " + phoneNumber;
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(phoneNumber)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void verifyPhoneNumberWithCode(String code) {
        if (mContext == null) return;
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, code);
        signInWithPhoneAuthCredential(credential);
    }


    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            CustomLog.trace("DEBUG: signInWithCredential:success");

                            FirebaseUser user = task.getResult().getUser();
                            user.getPhoneNumber();
                            CustomLog.trace("DEBUG: " + user.getPhoneNumber());

                            Toast.makeText(mContext, "Login successfully...", Toast.LENGTH_SHORT).show();

                            mPreferencesSession.saveStringData(PreferenceKey.ROLE, PreferenceKey.CUSTOMER_ROLE);
                            mPreferencesSession.saveStringData(PreferenceKey.USER_ID, user.getPhoneNumber());
                            Intent intent = new Intent(LoginActivity.this, LanguageChooseActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();

                        } else {
                            // Sign in failed, display a message and update the UI
                            CustomLog.trace("DEBUG: signInWithCredential:failure: " + task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                            }

                            Toast.makeText(mContext, "Login failed...", Toast.LENGTH_SHORT).show();
                            loader.setVisibility(View.GONE);
                            hld_phone_number.setVisibility(View.VISIBLE);
                            btn_login.setVisibility(View.VISIBLE);
                            btn_submit_otp.setVisibility(View.GONE);
                            hld_otp.setVisibility(View.GONE);
                            label.setText("Please enter your mobile number to continue.");
                        }
                    }
                });
    }
}