package com.pemchip.governmentschemes.model;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.pemchip.governmentschemes.common.CommonUtils;
import com.pemchip.governmentschemes.common.PreferenceKey;
import com.pemchip.governmentschemes.common.PreferencesSession;

import java.util.Locale;

public class BaseActivity extends AppCompatActivity {

    public PreferencesSession mPreferencesSession;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPreferencesSession = PreferencesSession.getInstance(this);
    }

    public void setAppLocale(){
        if(mPreferencesSession==null)return;

        String mCurrentAppLanguage = mPreferencesSession.getStringData(PreferenceKey.APP_LANGUAGE);
        if(CommonUtils.isEmptyStr(mCurrentAppLanguage)){
            mCurrentAppLanguage = "en";
        }
        Resources resources = getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        Configuration config = resources.getConfiguration();
        config.setLocale(new Locale(mCurrentAppLanguage.toLowerCase()));
        resources.updateConfiguration(config, dm);
    }
}
