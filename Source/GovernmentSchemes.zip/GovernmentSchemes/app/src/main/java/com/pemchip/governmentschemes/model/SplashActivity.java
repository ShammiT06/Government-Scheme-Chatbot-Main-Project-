package com.pemchip.governmentschemes.model;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.pemchip.governmentschemes.R;
import com.pemchip.governmentschemes.common.CustomLog;
import com.pemchip.governmentschemes.common.PreferenceKey;

public class SplashActivity extends BaseActivity {

    private ImageView image;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        setAppLocale();
        setContentView(R.layout.splash_screen);
        mAuth = FirebaseAuth.getInstance();
        setUpView();
    }

    private void setUpView() {

        image = findViewById(R.id.image);
        Glide.with(this).load(R.drawable.logo_english).into(image);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                CustomLog.trace("DEBUG: isUserLogged: " + mPreferencesSession.isLoggedIn());
                CustomLog.trace("DEBUG: Role: " + mPreferencesSession.getUserRole());
                CustomLog.trace("TOKEN: " + mPreferencesSession.getStringData(PreferenceKey.FCM_TOKEN));
                if (mPreferencesSession.isLoggedIn()) {
                    checkFireBaseAuth();
                } else {
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    finish();
                }
            }
        }, 4000);

    }

    private void checkFireBaseAuth() {
        if (mAuth == null) return;
        CustomLog.trace("DEBUG: checkFireBaseAuth:");
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            CustomLog.trace("DEBUG: Email: " + user.getPhoneNumber());
            mPreferencesSession.saveStringData(PreferenceKey.USER_ID, user.getPhoneNumber());
            startActivity(new Intent(SplashActivity.this, HomeActivity.class));
            finish();
        }
    }
}
